import Calendar from "@/components/calendar"

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold text-gray-900 mb-3">Year Calendar</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            A complete view of the year with all important holidays and events highlighted.
          </p>
        </div>
        <Calendar />
      </div>
    </main>
  )
}

