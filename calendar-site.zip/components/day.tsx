"use client"

import type { Holiday } from "@/data/holidays"
import { useState } from "react"

interface DayProps {
  day: number
  isCurrentMonth: boolean
  isToday: boolean
  holiday?: Holiday
  isPastDate: boolean
}

export default function Day({ day, isCurrentMonth, isToday, holiday, isPastDate }: DayProps) {
  const [showTooltip, setShowTooltip] = useState(false)

  if (!isCurrentMonth) {
    return <div className="flex items-center justify-center h-9"></div>
  }

  return (
    <div className="flex items-center justify-center h-9 relative">
      <div
        className={`
          w-8 h-8 flex items-center justify-center rounded-full
          ${isToday ? "bg-blue-500 text-white" : ""}
          ${holiday && !isPastDate ? holiday.color + " text-white" : ""}
          ${holiday && isPastDate ? "bg-red-200 text-gray-600" : ""}
          ${isPastDate && !isToday && !holiday ? "text-gray-400" : ""}
          ${holiday && isToday ? "ring-2 ring-yellow-300" : ""}
          ${isPastDate ? "cursor-not-allowed" : "cursor-pointer hover:bg-gray-50"}
          transition-colors text-sm
        `}
        onMouseEnter={() => holiday && setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
      >
        {day}
      </div>

      {showTooltip && holiday && (
        <div className="absolute z-10 bg-gray-800 text-white text-xs rounded py-1 px-2 left-1/2 transform -translate-x-1/2 bottom-full mb-1 whitespace-nowrap">
          {holiday.name}
        </div>
      )}
    </div>
  )
}

