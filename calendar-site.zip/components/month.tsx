"use client"

import { useMemo } from "react"
import Day from "./day"
import { type Holiday, isHoliday } from "@/data/holidays"

interface MonthProps {
  month: string
  monthIndex: number
  year: number
  holidays: Holiday[]
}

export default function Month({ month, monthIndex, year, holidays }: MonthProps) {
  // Get current date for comparison
  const today = new Date()
  const currentDay = today.getDate()
  const currentMonth = today.getMonth()
  const currentYear = today.getFullYear()

  const isCurrentMonth = currentMonth === monthIndex && currentYear === year

  // Filter holidays for this specific month
  const monthHolidays = useMemo(() => {
    return holidays.filter((holiday) => holiday.month === monthIndex).sort((a, b) => a.day - b.day)
  }, [monthIndex, holidays])

  const days = useMemo(() => {
    const daysInMonth = new Date(year, monthIndex + 1, 0).getDate()
    const firstDayOfMonth = new Date(year, monthIndex, 1).getDay()

    // Create array for days of the month
    const daysArray = []

    // Add empty spaces for days before the 1st of the month
    for (let i = 0; i < firstDayOfMonth; i++) {
      daysArray.push({
        day: 0,
        isCurrentMonth: false,
        holiday: undefined,
        isPastDate: false,
      })
    }

    // Add days of the month
    for (let i = 1; i <= daysInMonth; i++) {
      const holiday = isHoliday(i, monthIndex, holidays)

      // Determine if this date is in the past
      let isPastDate = false

      if (year < currentYear) {
        // All dates from previous years are in the past
        isPastDate = true
      } else if (year === currentYear) {
        if (monthIndex < currentMonth) {
          // All dates from previous months in the current year are in the past
          isPastDate = true
        } else if (monthIndex === currentMonth && i < currentDay) {
          // Only dates before today in the current month are in the past
          isPastDate = true
        }
      }

      daysArray.push({
        day: i,
        isCurrentMonth: true,
        holiday,
        isPastDate,
      })
    }

    return daysArray
  }, [monthIndex, year, holidays, currentDay, currentMonth, currentYear])

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg">
      <div className="bg-gradient-to-r from-rose-50 to-rose-100 px-4 py-3">
        <h3 className="text-xl font-bold text-gray-800 text-center">{month}</h3>
      </div>
      <div className="p-4">
        <div className="grid grid-cols-7 mb-2">
          {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((day) => (
            <div
              key={day}
              className="text-center text-xs font-medium text-gray-500 h-6 flex items-center justify-center"
            >
              {day}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7">
          {days.map((day, index) => (
            <Day
              key={index}
              day={day.day}
              isCurrentMonth={day.isCurrentMonth}
              isToday={isCurrentMonth && day.day === currentDay}
              holiday={day.holiday}
              isPastDate={day.isPastDate}
            />
          ))}
        </div>

        {/* Holiday information list - without totals */}
        {monthHolidays.length > 0 && (
          <div className="mt-4 pt-3 border-t border-gray-200">
            <h4 className="text-sm font-semibold mb-2 text-gray-700">Holidays:</h4>
            <ul className="text-xs space-y-1.5">
              {monthHolidays.map((holiday) => (
                <li key={`${holiday.month}-${holiday.day}`} className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-red-500 mr-2 flex-shrink-0"></div>
                  <span className="font-medium">
                    {holiday.day} {month}:
                  </span>
                  <span className="ml-1 text-gray-600">{holiday.name}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  )
}

