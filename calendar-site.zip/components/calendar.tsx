"use client"

import { useState, useEffect, useMemo } from "react"
import { ChevronLeft, ChevronRight, CalendarIcon, CalendarDaysIcon } from "lucide-react"
import Month from "./month"
import { indonesianHolidays } from "@/data/holidays"

export default function Calendar() {
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear())
  const [months, setMonths] = useState<string[]>([])

  useEffect(() => {
    setMonths([
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ])
  }, [])

  // Calculate total holidays for the year
  const yearlyHolidayTotal = useMemo(() => {
    return indonesianHolidays.length
  }, [])

  const handlePrevYear = () => {
    setCurrentYear(currentYear - 1)
  }

  const handleNextYear = () => {
    setCurrentYear(currentYear + 1)
  }

  return (
    <div className="space-y-8">
      {/* Beautiful Header */}
      <div className="bg-gradient-to-r from-rose-100 to-teal-100 rounded-xl p-6 shadow-md">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-4 flex-wrap justify-center sm:justify-start">
            <h2 className="text-3xl font-bold text-gray-800 flex items-center">
              <CalendarIcon className="mr-2 h-8 w-8 text-rose-500" />
              <span className="relative">
                {currentYear}
                <span className="absolute -bottom-2 left-0 right-0 h-1 bg-rose-500 rounded-full"></span>
              </span>
            </h2>

            {/* Yearly Holiday Total - Now next to year */}
            <div className="bg-white px-3 py-1.5 rounded-lg shadow-sm flex items-center gap-2">
              <CalendarDaysIcon className="h-4 w-4 text-red-500" />
              <span className="text-sm font-medium">Holidays: </span>
              <span className="bg-red-500 text-white px-2 py-0.5 rounded-full text-xs font-bold">
                {yearlyHolidayTotal}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handlePrevYear}
              className="flex items-center justify-center h-10 w-10 rounded-full bg-white shadow-sm hover:bg-gray-50 transition-all duration-200 hover:shadow-md text-gray-700"
              aria-label="Previous Year"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>

            <div className="bg-white px-4 py-2 rounded-lg shadow-sm font-medium">Year View</div>

            <button
              onClick={handleNextYear}
              className="flex items-center justify-center h-10 w-10 rounded-full bg-white shadow-sm hover:bg-gray-50 transition-all duration-200 hover:shadow-md text-gray-700"
              aria-label="Next Year"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {months.map((month, index) => (
          <Month key={month} month={month} monthIndex={index} year={currentYear} holidays={indonesianHolidays} />
        ))}
      </div>
    </div>
  )
}

