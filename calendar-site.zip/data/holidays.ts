export interface Holiday {
  month: number // 0-11 (JavaScript months)
  day: number
  name: string
  color: string
}

// Example Indonesian holidays for demonstration
export const indonesianHolidays: Holiday[] = [
  { month: 0, day: 1, name: "New Year's Day", color: "bg-red-500" },
  { month: 0, day: 25, name: "Chinese New Year", color: "bg-red-500" },
  { month: 2, day: 11, name: "Isra Mi'raj", color: "bg-red-500" },
  { month: 2, day: 22, name: "Nyepi (Balinese New Year)", color: "bg-red-500" },
  { month: 3, day: 7, name: "Good Friday", color: "bg-red-500" },
  { month: 3, day: 21, name: "Eid al-Fitr", color: "bg-red-500" },
  { month: 3, day: 22, name: "Eid al-Fitr Holiday", color: "bg-red-500" },
  { month: 4, day: 1, name: "Labor Day", color: "bg-red-500" },
  { month: 4, day: 9, name: "Vesak Day", color: "bg-red-500" },
  { month: 4, day: 17, name: "Ascension Day", color: "bg-red-500" },
  { month: 5, day: 1, name: "Pancasila Day", color: "bg-red-500" },
  { month: 5, day: 17, name: "Eid al-Adha", color: "bg-red-500" },
  { month: 6, day: 7, name: "Islamic New Year", color: "bg-red-500" },
  { month: 7, day: 17, name: "Independence Day", color: "bg-red-500" },
  { month: 8, day: 16, name: "Prophet Muhammad's Birthday", color: "bg-red-500" },
  { month: 11, day: 25, name: "Christmas Day", color: "bg-red-500" },
  { month: 11, day: 26, name: "Boxing Day", color: "bg-red-500" },
]

// Function to check if a date is a holiday
export function isHoliday(day: number, month: number, holidays: Holiday[]): Holiday | undefined {
  return holidays.find((holiday) => holiday.day === day && holiday.month === month)
}

